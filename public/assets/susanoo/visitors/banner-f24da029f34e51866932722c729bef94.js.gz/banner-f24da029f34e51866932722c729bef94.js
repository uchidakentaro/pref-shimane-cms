BANNERS = [{"url":"http://yahoo.co.jp","alt":"テスト広告3","image":"/images/advertisement/3.jpg"},{"url":"http://www.netlab.jp","alt":"テスト_4","image":"/images/advertisement/7.jpg"}]
;
